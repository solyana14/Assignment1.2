package com.company;

import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String contin = "1";
        while(!"0".equals(contin)) {
            System.out.print("Write IP address of the server: ");
            String choice = input.next();
            process(choice);
            System.out.println();
            System.out.println("Enter any key to continue and 0  to end: ");
            contin = input.next().toLowerCase();
        }

    }

    public static void process(String choice){
        try {
            //create OS processes
            ProcessBuilder builder = new ProcessBuilder(
                    "cmd.exe", "/c","ping " + choice +   " -t -l 2000");
            builder.redirectErrorStream(true);
            //create instance proccess with above attributes
            Process p = builder.start();
            //read data of the standard output from pipe via input stream
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true) {
                //read line of text
                line = r.readLine();
                if (line == null) { break; }
                System.out.println(line);
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}
